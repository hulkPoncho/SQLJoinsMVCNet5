﻿using Consultas.Models;
using System.Collections.Generic;

namespace Consultas.IServices
{
    public interface IConsultasService
    {
        List<ElementoConsulta> ConsultaDepartamentos_ConsultaInclusiva();
        List<ElementoConsulta> ConsultaDepartamentos_ConsultaExclusiva();
        List<ElementoConsulta> ConsultaTotal();
        List<ElementoConsulta> ConsultaDepartamentosConEmpleados();
        List<ElementoConsulta> ConsultaDepartamentosEmpleadosDesconectados();
        List<ElementoConsulta> ConsultaEmpleados_ConsultaInclusiva();
        List<ElementoConsulta> ConsultaEmpleados_ConsultaExclusiva();
    }
}
