﻿namespace Consultas.Models
{
    public class Argumento
    {
        public string Titulo { get; internal set; }
        public string Descripcion { get; internal set; }
        public string Codigo { get; internal set; }
        public string NombreArchivoExcel { get; internal set; }
        public string Imagen { get; internal set; }
    }
}
