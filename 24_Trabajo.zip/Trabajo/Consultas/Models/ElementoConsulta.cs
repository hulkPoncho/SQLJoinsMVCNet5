﻿namespace Consultas.Models
{
    public class ElementoConsulta
    {
        public string EmpleadoNombre { get; set; }
        public int? EmpleadoId { get; set; }
        public int? DepartamentoId { get; set; }
        public string DepartamentoNombre { get; set; }
    }
}
