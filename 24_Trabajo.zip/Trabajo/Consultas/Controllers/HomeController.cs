﻿using Consultas.IServices;
using Consultas.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Consultas.Controllers
{
    public class HomeController : BaseController
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IConsultasService _IConsultasService;
        private readonly IConfiguration _IConfiguration;

        public HomeController(ILogger<HomeController> logger,
            IConsultasService consultasService, IConfiguration configuration)
        {
            _logger = logger;
            _IConsultasService = consultasService;
            _IConfiguration = configuration;
        }

        public IActionResult Index(int indice=0)
        {
            if (indice < 0 || indice > 6) indice = 0;
            var lista = ObtenerConsulta(indice);

            var path = _IConfiguration["Parametros:RutaTrabajo"];
            var Argumento = ObtenerNarrativa(indice, path);
            ObtenerParamentrosRetorno(Argumento);
            return View(lista);
        }

        private void ObtenerParamentrosRetorno(Argumento _Argumento)
        {
            ViewBag.Titulo = _Argumento.Titulo;
            ViewBag.Descripcion = _Argumento.Descripcion;
            ViewBag.Codigo = _Argumento.Codigo;
            ViewBag.Imagen = _Argumento.Imagen;
            ViewBag.NombreArchivoExcel = _Argumento.NombreArchivoExcel;
        }

        public List<ElementoConsulta> ObtenerConsulta(int indice)
        {
            var Resultado = new List<ElementoConsulta>();
            switch (indice)
            {
                case 0:
                    Resultado = _IConsultasService.ConsultaDepartamentos_ConsultaInclusiva();
                    break;
                case 1:
                    Resultado = _IConsultasService.ConsultaDepartamentos_ConsultaExclusiva();
                    break;
                case 2:
                    Resultado = _IConsultasService.ConsultaTotal();
                    break;
                case 3:
                    Resultado = _IConsultasService.ConsultaDepartamentosConEmpleados();
                    break;
                case 4:
                    Resultado = _IConsultasService.ConsultaDepartamentosEmpleadosDesconectados();
                    break;
                case 5:
                    Resultado = _IConsultasService.ConsultaEmpleados_ConsultaInclusiva();
                    break;
                case 6:
                    Resultado = _IConsultasService.ConsultaEmpleados_ConsultaExclusiva();
                    break;
            }
            Resultado = Resultado.OrderBy(s => s.EmpleadoId).ThenBy(s => s.DepartamentoId).ToList();
            return Resultado;
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
