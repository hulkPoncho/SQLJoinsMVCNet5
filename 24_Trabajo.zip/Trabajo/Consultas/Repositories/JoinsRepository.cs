﻿using Consultas.Entidades;
using Consultas.IRepositories;
using Consultas.Models;
using System.Collections.Generic;
using System.Linq;

namespace Consultas.Repositories
{
    public class JoinsRepository : IConsultasRepository
    {
        private readonly ConsultasContext _context;

        public JoinsRepository(ConsultasContext context)
        {
            _context = context;
        }

        public List<ElementoConsulta> ConsultaDepartamentosConEmpleados()
        {
            var lista = (from d in _context.Departamento
                         join e in _context.Empleado 
                         on d.DepartamentoId equals e.DepartamentoId
                         select new ElementoConsulta
                         {
                             DepartamentoNombre = d.Nombre,
                             DepartamentoId = d.DepartamentoId,
                             EmpleadoId = e.EmpleadoId,
                             EmpleadoNombre = e.Nombre
                         }).ToList();
            return lista;
        }

        public List<ElementoConsulta> ConsultaDepartamentosEmpleadosDesconectados()
        {
            // Ids de los departamentos que si tienen empleados asociados
            var deptosIds = _context.Empleado.Select(s => s.DepartamentoId).Distinct().ToList();

            // Consulta departamentos que no están en deptosIds
            var consultaIzq = (from d in _context.Departamento
                               where !deptosIds.Contains(d.DepartamentoId)
                               select
                               new ElementoConsulta
                               {
                                   EmpleadoNombre = null,
                                   EmpleadoId = null,
                                   DepartamentoNombre = d.Nombre,
                                   DepartamentoId = d.DepartamentoId
                               }).ToList();

            // Empleados sin departamento asociado
            var consultaDer = (from team in _context.Empleado
                               where team.DepartamentoId == null
                               select new ElementoConsulta
                               {
                                   DepartamentoId = null,
                                   DepartamentoNombre = null,
                                   EmpleadoNombre = team.Nombre,
                                   EmpleadoId = team.EmpleadoId
                               }).ToList();

            // Concatenación de los 2 listados
            var lista = consultaIzq.Concat(consultaDer).ToList();
            return lista;

        }

        public List<ElementoConsulta> ConsultaDepartamentos_ConsultaExclusiva()
        {
            var lista = (from d in _context.Departamento
                         join e in _context.Empleado
                         on d.DepartamentoId equals e.DepartamentoId into emp
                         
                         from empleado in emp.DefaultIfEmpty() where empleado == null

                         select new ElementoConsulta
                         {
                             DepartamentoNombre = d.Nombre,
                             DepartamentoId = d.DepartamentoId,
                         }).ToList();
            return lista;

        }

        public List<ElementoConsulta> ConsultaDepartamentos_ConsultaInclusiva()
        {
            var lista = (from d in _context.Departamento
                         join e in _context.Empleado
                         on d.DepartamentoId equals e.DepartamentoId

                         // Valores por defecto
                         into emp from empleado in emp.DefaultIfEmpty()

                         select new ElementoConsulta
                         {
                             EmpleadoNombre = empleado.Nombre,
                             EmpleadoId = empleado.EmpleadoId,
                             DepartamentoId = d.DepartamentoId,
                             DepartamentoNombre = d.Nombre
                         }).ToList();
            return lista;
        }

        public List<ElementoConsulta> ConsultaEmpleados_ConsultaExclusiva()
        {
            var lista = (from d in _context.Empleado
                         join e in _context.Departamento
                         on d.DepartamentoId equals e.DepartamentoId into depto

                         from departamento in depto.DefaultIfEmpty()
                         where departamento == null

                         select new ElementoConsulta
                         {
                             DepartamentoNombre = d.Nombre,
                             DepartamentoId = d.DepartamentoId,
                         }).ToList();
            return lista;
        }

        public List<ElementoConsulta> ConsultaEmpleados_ConsultaInclusiva()
        {
            var lista = (from d in _context.Empleado
                         join e in _context.Departamento
                         on d.DepartamentoId equals e.DepartamentoId

                         // Valores por defecto
                         into depto
                         from departamento in depto.DefaultIfEmpty()

                         select new ElementoConsulta
                         {
                             EmpleadoNombre = d.Nombre,
                             EmpleadoId = d.EmpleadoId,
                             DepartamentoId = departamento.DepartamentoId,
                             DepartamentoNombre = departamento.Nombre,
                         }).ToList();
            return lista;

        }

        public List<ElementoConsulta> ConsultaTotal()
        {
            var leftOuterJoin = from left in _context.Departamento
                                join right in _context.Empleado on left.DepartamentoId equals right.DepartamentoId
                                into temp
                                from right in temp.DefaultIfEmpty()
                                select new { left, right };

            var rightOuterJoin = from right in _context.Empleado
                                 join left in _context.Departamento on right.DepartamentoId equals left.DepartamentoId
                                 into temp
                                 from left in temp.DefaultIfEmpty()
                                 select new { left, right };

            var resultado = leftOuterJoin.Union(rightOuterJoin);

            var lista = (from d in resultado
                         select new ElementoConsulta
                         {
                             DepartamentoNombre = d.left.Nombre,
                             DepartamentoId = d.left.DepartamentoId,
                             EmpleadoId = d.right.EmpleadoId,
                             EmpleadoNombre = d.right.Nombre
                         }).ToList();

            return lista;

        }
    }
}
