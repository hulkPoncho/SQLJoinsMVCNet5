﻿using Consultas.Entidades;
using Consultas.IRepositories;
using Consultas.Models;
using System.Collections.Generic;
using System.Linq;

namespace Consultas.Repositories
{
    public class ExtensionsRepository: IConsultasRepository
    {
        private readonly ConsultasContext _context;

        public ExtensionsRepository(ConsultasContext context)
        {
            _context = context;
        }

        public List<ElementoConsulta> ConsultaDepartamentos_ConsultaExclusiva()
        {
            var resultado = _context.Departamento.LeftExcludingJoin(        /// Source Collection
                    _context.Empleado,                                      /// Inner Collection
                    p => p.DepartamentoId,                                  /// PK
                    a => a.DepartamentoId,                                  /// FK
                    (p, a) => new { Departamento = p, Empleado = a })       /// Collection
                    .Select(a => new ElementoConsulta
                    {
                        DepartamentoNombre = a.Departamento.Nombre,
                        DepartamentoId = a.Departamento.DepartamentoId,
                        EmpleadoId = (a.Empleado?.EmpleadoId),
                        EmpleadoNombre = (a.Empleado?.Nombre),
                    });

            return resultado.ToList();
        }

        public List<ElementoConsulta> ConsultaDepartamentosEmpleadosDesconectados()
        {
            var resultado = _context.Departamento.FulltExcludingJoin(          /// Source Collection  
                    _context.Empleado,                                         /// Inner Collection  
                    p => p.DepartamentoId,                                     /// PK  
                    a => a.DepartamentoId,                                     /// FK  
                    (p, a) => new { Departamento = p, Empleado = a })          /// Collection  
                    .Select(a => new ElementoConsulta
                    {
                        DepartamentoNombre = a.Departamento?.Nombre,
                        DepartamentoId = a.Departamento?.DepartamentoId,
                        EmpleadoId = a.Empleado?.EmpleadoId,
                        EmpleadoNombre = a.Empleado?.Nombre,
                    });
            return resultado.ToList();
        }

        public List<ElementoConsulta> ConsultaDepartamentos_ConsultaInclusiva()
        {
            var resultado = _context.Departamento.LeftJoin(             /// Source Collection
                    _context.Empleado,                                  /// Inner Collection
                    p => p.DepartamentoId,                              /// PK
                    a => a.DepartamentoId,                              /// FK
                    (p, a) => new { Departamento = p, Empleado = a })   /// Collection
                    .Select(a => new ElementoConsulta
                    {
                        DepartamentoNombre = a.Departamento.Nombre,
                        DepartamentoId = a.Departamento.DepartamentoId,
                        EmpleadoId = a.Empleado?.EmpleadoId,
                        EmpleadoNombre = a.Empleado?.Nombre,
                    });
            return resultado.ToList();
        }

        public List<ElementoConsulta> ConsultaEmpleados_ConsultaExclusiva()
        {
            var resultado = _context.Departamento.RightExcludingJoin(            /// Source Collection  
                    _context.Empleado,                                           /// Inner Collection  
                    p => p.DepartamentoId,                                       /// PK  
                    a => a.DepartamentoId,                                       /// FK  
                    (p, a) => new { Departamento = p, Empleado = a })            /// Result Collection  
                    .Select(a => new ElementoConsulta
                    {
                        DepartamentoNombre = (a.Departamento?.Nombre),
                        DepartamentoId = (a.Departamento?.DepartamentoId),
                        EmpleadoNombre = a.Empleado.Nombre,
                        EmpleadoId = a.Empleado.EmpleadoId,
                    });
            return resultado.ToList();
        }

        public List<ElementoConsulta> ConsultaEmpleados_ConsultaInclusiva()
        {
            var resultado = _context.Departamento.RightJoin(              /// Source Collection  
                    _context.Empleado,                                    /// Inner Collection  
                    p => p.DepartamentoId,                                /// PK  
                    a => a.DepartamentoId,                                /// FK  
                    (p, a) => new { Departamento = p, Empleado = a })     /// Result Collection  
                    .Select(a => new ElementoConsulta
                    {
                        DepartamentoNombre = (a.Departamento?.Nombre),
                        DepartamentoId = (a.Departamento?.DepartamentoId),
                        EmpleadoId = a.Empleado.EmpleadoId,
                        EmpleadoNombre = a.Empleado.Nombre,
                    });
            return resultado.ToList();
        }

        public List<ElementoConsulta> ConsultaTotal()
        {
            var resultJoint = _context.Departamento.FullOuterJoinJoin(           /// Source Collection  
                    _context.Empleado,                                           /// Inner Collection  
                    p => p.DepartamentoId,                                       /// PK  
                    a => a.DepartamentoId,                                       /// FK  
                    (p, a) => new { Departamento = p, Empleado = a })            /// Result Collection  
                    .Select(a => new ElementoConsulta
                    {
                        DepartamentoNombre = (a.Departamento?.Nombre),
                        DepartamentoId = (a.Departamento?.DepartamentoId),
                        EmpleadoId = (a.Empleado?.EmpleadoId),
                        EmpleadoNombre = (a.Empleado?.Nombre)
                    });
            return resultJoint.ToList();
        }

        public List<ElementoConsulta> ConsultaDepartamentosConEmpleados()
        {
            var resultado = _context.Departamento.Join(             /// Source Collection
                  _context.Empleado,                                /// Inner Collection
                  p => p.DepartamentoId,                            /// PK
                  a => a.DepartamentoId,                            /// FK
                  (p, a) => new { Departamento = p, Empleado = a }) /// Result Collection
                  .Select(a => new ElementoConsulta
                  {
                      DepartamentoNombre = (a.Departamento.Nombre),
                      DepartamentoId = (a.Departamento.DepartamentoId),
                      EmpleadoId = (a.Empleado.EmpleadoId),
                      EmpleadoNombre = (a.Empleado.Nombre)
                  });
            return resultado.ToList();
        }

    }
}
