﻿using Consultas.Models;
using System.Collections.Generic;

namespace Consultas.IRepositories
{
    public interface IConsultasRepository
    {
        List<ElementoConsulta> ConsultaDepartamentos_ConsultaExclusiva();
        List<ElementoConsulta> ConsultaDepartamentos_ConsultaInclusiva();
        List<ElementoConsulta> ConsultaTotal();
        List<ElementoConsulta> ConsultaDepartamentosConEmpleados();
        List<ElementoConsulta> ConsultaDepartamentosEmpleadosDesconectados();
        List<ElementoConsulta> ConsultaEmpleados_ConsultaInclusiva();
        List<ElementoConsulta> ConsultaEmpleados_ConsultaExclusiva();
    }
}
