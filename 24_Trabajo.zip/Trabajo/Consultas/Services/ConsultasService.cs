﻿using Consultas.IRepositories;
using Consultas.IServices;
using Consultas.Models;
using System.Collections.Generic;

namespace Consultas.Services
{
    public class ConsultasService : IConsultasService
    {
        private readonly IConsultasRepository _IConsultasRepository;

        public ConsultasService(IConsultasRepository consultasRepository)
        {
            _IConsultasRepository = consultasRepository;
        }

        public List<ElementoConsulta> ConsultaDepartamentosConEmpleados()
        {
            return _IConsultasRepository.ConsultaDepartamentosConEmpleados();
        }

        public List<ElementoConsulta> ConsultaDepartamentosEmpleadosDesconectados()
        {
            return _IConsultasRepository.ConsultaDepartamentosEmpleadosDesconectados();
        }

        public List<ElementoConsulta> ConsultaDepartamentos_ConsultaExclusiva()
        {
            return _IConsultasRepository.ConsultaDepartamentos_ConsultaExclusiva();
        }

        public List<ElementoConsulta> ConsultaDepartamentos_ConsultaInclusiva()
        {
            return _IConsultasRepository.ConsultaDepartamentos_ConsultaInclusiva();
        }

        public List<ElementoConsulta> ConsultaEmpleados_ConsultaExclusiva()
        {
            return _IConsultasRepository.ConsultaEmpleados_ConsultaExclusiva();
        }

        public List<ElementoConsulta> ConsultaEmpleados_ConsultaInclusiva()
        {
            return _IConsultasRepository.ConsultaEmpleados_ConsultaInclusiva();
        }

        public List<ElementoConsulta> ConsultaTotal()
        {
            return _IConsultasRepository.ConsultaTotal();
        }
    }
}
