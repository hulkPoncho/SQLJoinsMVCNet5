using Consulta.Models;
using Consultas.Entidades;
using Consultas.IRepositories;
using Consultas.IServices;
using Consultas.Repositories;
using Consultas.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Consultas
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<ConsultasContext>
                (option => option.UseSqlServer(Configuration.GetConnectionString("Conexion")));
            services.AddSingleton<DapperContext>();

            InsercionDependenciasServicios(services);

            services.AddControllersWithViews();
        }

        private void InsercionDependenciasServicios(IServiceCollection services)
        {
            var ORM = Configuration["Parametros:ORM"];
            switch (ORM)
            {
                case "DAPPER":
                    services.AddScoped<IConsultasService, ConsultasService>();
                    services.AddScoped<IConsultasRepository, DapperRepository>();
                    break;
                case "LINQ":
                    services.AddScoped<IConsultasService, ConsultasService>();
                    services.AddScoped<IConsultasRepository, JoinsRepository>();
                    break;
                case "LINQ&EXTENSION":
                    services.AddScoped<IConsultasService, ConsultasService>();
                    services.AddScoped<IConsultasRepository, ExtensionsRepository>();
                    break;
                default:
                    services.AddScoped<IConsultasService, ConsultasService>();
                    services.AddScoped<IConsultasRepository, JoinsRepository>();
                    break;
            }
        }


        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
